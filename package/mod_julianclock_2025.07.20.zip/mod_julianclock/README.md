JulianClock
========
![GitHub release (latest by date)](https://img.shields.io/github/v/release/N6REJ/mod_julianclock)
![GitHub top language](https://img.shields.io/github/languages/top/N6REJ/mod_julianclock)
![GitHub All Releases](https://img.shields.io/github/downloads/N6REJ/mod_julianclock/total)
![License: GPL v3](https://img.shields.io/badge/License-GPLv3-blue.svg)
========
A live-clock based on Javascript & php for Joomla 3.
With up to 10 digit decimal display!
Source Time is fixed on UTC
deltaT is not utilized in this clock

![image](https://github.com/user-attachments/assets/6bdcbf5f-15a4-49ef-92dd-b5f9da6434ff)
